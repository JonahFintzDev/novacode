# Handoff: Nova Code — Design Refresh

## Overview

A visual redesign of **Nova Code**, the in-house AI coding agent manager. Functionality stays exactly as it is today — this is a re-skin only. The goals stated by the product owner:

- Give Nova Code a **distinct identity as a developer tool** (not a generic SaaS dashboard).
- Reduce **visual noise**: fewer borders, fewer boxes, fewer dividers.
- Better **typographic hierarchy** and a **better-used color palette**.
- More **breathing room** (less dense than before).
- **Modernize the modals**.
- Keep all current behavior, all current settings, all current tabs.
- **Light mode** is now a first-class citizen alongside dark.
- Sidebar should be **collapsible to an icon-only rail**.

## About the Design Files

The files bundled here are **HTML / React design references** — prototypes that show the intended look, hierarchy, and small interactions. They are not production code and should not be shipped or copy-pasted as-is.

The task is to **recreate these designs in the existing Nova Code codebase**, using the existing components, framework (Vue from the original code references in the chat history), state management, and routing. Where the design conflicts with current functionality, **functionality wins** — flag any conflict and ask. Where the design adds new visual treatment for an existing setting/feature, just re-skin it; do not add or remove any options, tabs, or behavior.

## Fidelity

**High-fidelity (hifi).** Final colors, typography, spacing, radii, and component shapes are as specified below. Recreate pixel-faithful in the target codebase using its design tokens / component library; introduce new tokens where the current ones cannot express the new system.

## Design System

### Color tokens

The system uses CSS custom properties on `:root[data-theme="dark"]` and `:root[data-theme="light"]`. Every surface color comes from a token — no inline hex except for the agent identity palette and the theme-preview swatches.

#### Dark (default)
| Token              | Hex / Value                       | Usage                                      |
| ------------------ | --------------------------------- | ------------------------------------------ |
| `--bg`             | `#0f0e0d`                         | App background (warm graphite, NOT pure black) |
| `--bg-elev`        | `#171614`                         | Sidebar items active, panels, cards        |
| `--bg-elev-2`      | `#1d1b18`                         | Modals, popovers, second-level surfaces    |
| `--bg-hover`       | `#23201d`                         | Row hover                                  |
| `--line`           | `rgba(255, 248, 235, 0.06)`       | Subtle dividers                            |
| `--line-strong`    | `rgba(255, 248, 235, 0.10)`       | Visible borders, scrollbar thumbs          |
| `--fg`             | `#f5f1ea`                         | Primary text                               |
| `--fg-muted`       | `#a6a098`                         | Secondary text                             |
| `--fg-subtle`      | `#6e6963`                         | Captions, eyebrows, mono labels            |
| `--fg-faint`       | `#48443f`                         | Disabled, hairline text                    |
| `--accent`         | `#8b85ff`                         | Single accent (desaturated indigo)         |
| `--accent-soft`    | `rgba(139, 133, 255, 0.14)`       | Accent backgrounds                         |
| `--accent-line`    | `rgba(139, 133, 255, 0.28)`       | Accent borders / focus rings               |
| `--success`        | `#7ec994`                         | Status, "Authenticated"/"Configured" chips |
| `--warn`           | `#e6b067`                         | Busy state, modified files                 |
| `--danger`         | `#e87676`                         | Destructive actions                        |
| `--agent-claude`   | `#d97757`                         | Claude identity                            |
| `--agent-cursor`   | `#7aa2ff`                         | Cursor identity                            |
| `--agent-vibe`     | `#7ec994`                         | Mistral Vibe identity                      |

#### Light
| Token              | Hex / Value                       |
| ------------------ | --------------------------------- |
| `--bg`             | `#f6f3ec` (warm off-white)        |
| `--bg-elev`        | `#fbf9f4`                         |
| `--bg-elev-2`      | `#ffffff`                         |
| `--bg-hover`       | `#eee9df`                         |
| `--line`           | `rgba(25, 20, 10, 0.08)`          |
| `--line-strong`    | `rgba(25, 20, 10, 0.14)`          |
| `--fg`             | `#1a1815`                         |
| `--fg-muted`       | `#56524b`                         |
| `--fg-subtle`      | `#807a70`                         |
| `--fg-faint`       | `#b5afa4`                         |
| `--accent`         | `#4f48e6`                         |
| `--accent-soft`    | `rgba(79, 72, 230, 0.10)`         |
| `--accent-line`    | `rgba(79, 72, 230, 0.24)`         |
| `--success`        | `#3f8a5a`                         |
| `--warn`           | `#b37410`                         |
| `--danger`         | `#b3452e`                         |
| `--agent-claude`   | `#b05a3c`                         |
| `--agent-cursor`   | `#3a6ad9`                         |
| `--agent-vibe`     | `#3f8a5a`                         |

### Typography

- **UI:** `Inter`, weights 400 / 450 / 500 / 550 / 600. Letter-spacing `-0.005em` global, `-0.02em` on H1, `-0.01em` on card titles. Feature settings: `'cv11', 'ss01', 'ss03'`.
- **Mono:** `JetBrains Mono`, weights 400 / 500 / 600. Used for paths, file names, agent tags, eyebrows, kbd chips, numerals in stat blocks. Feature settings: `'ss02', 'ss19'`.
- **Eyebrow style** (used to anchor every page): mono, `10.5px`, `letter-spacing: 0.08em`, `text-transform: uppercase`, color `--fg-subtle`, prefixed with `// ` (e.g. `// home`, `// workspaces`, `// settings`). This is the single biggest identity move — keep it.

#### Type scale
| Role         | Size  | Weight | Notes                                          |
| ------------ | ----- | ------ | ---------------------------------------------- |
| Page H1      | 22px  | 600    | `letter-spacing: -0.02em`                      |
| Stat number  | 38px  | 500    | JetBrains Mono, tabular nums, `-0.03em`        |
| Card title   | 14px  | 550-600| `-0.01em`                                      |
| Body         | 13.5px| 450-500|                                                |
| Body small   | 13px  | 400    |                                                |
| Captions     | 12.5px| 400    | Color `--fg-subtle`                            |
| Mono labels  | 11–12px| 400-500| Paths, ws breadcrumbs, agent chips             |
| Eyebrow      | 10.5px| 500    | Mono, uppercase, `0.08em` tracking             |
| kbd chip     | 10.5px| 400    | Mono, on `--bg-elev-2`, 1px `--line` border    |

### Spacing & geometry

- Border radius: chips `4px`, buttons / inputs `6px`, cards / panels `10px`, modals `12px`.
- Section spacing on long pages: `36–40px` between major sections.
- Page gutters: `40px` horizontal, `32px` top, `40px` bottom.
- Max content width: `1040px`.
- **No box-shadows** anywhere except modals (`0 24px 60px rgba(0,0,0,0.6), 0 0 0 1px var(--line-strong)`).
- **No backdrop-blur** anywhere except modal overlays (`blur(4px)`).
- Borders are restricted to: tabs underline, sidebar/topbar bottom, settings rows divider, and individual chip outlines. Avoid the old "card with border + inner shadow" treatment.

### Buttons

- `.btn` — 30px height, `--line-strong` border, `--bg-hover` on hover.
- `.btn.primary` — solid `--fg` background, `--bg` text. (In light mode, this becomes a near-black button on cream.)
- `.btn.ghost` — transparent border; hover gives `--bg-hover`.
- `.btn.sm` — 26px height, 12.5px text. `.btn.icon.sm` is 26×26.

### Status / chips

- **Status dot:** 7px circle with a soft 3px halo (`box-shadow: 0 0 0 3px color-mix(...)` at 20% opacity).
  - `.busy` → `--warn` halo
  - `.active` / "Authenticated" → `--success` halo
  - `.idle` → `--fg-faint` no halo
- **Agent chip:** 20px tall, monospace, agent-tinted text on `--bg-elev-2`, 1px tinted border. Class: `chip agent-claude` / `agent-cursor` / `agent-vibe`.
- **Success "dot" chip:** small green dot before the label — used for "Authenticated", "Configured", "active".

### Toggles

- 34×19 capsule. Off: `--line-strong` track, `--fg-muted` knob. On: `--accent` track, white knob. 15×15 knob, 2px padding, transitions `transform .15s`.

## Sidebar

- **Width:** `232px` expanded / `56px` collapsed (icon rail).
- Collapse is per-user preference, persisted; topbar has a dedicated toggle.
- Brand area `56px` tall: 22×22 logomark (rounded-square with `< >` glyph in `--accent`) + "Nova Code" wordmark at 14.5px / 600.
- Primary nav: Home, Workspaces, Automations, Rule templates. Active item gets `--bg-elev` background AND a 2px `--accent` bar absolutely positioned at `left: -10px` from the row.
- **Sessions section header**: eyebrow `// sessions` (mono, uppercase). Removes the old heavy "Active & Recent Sessions" label.
- Each session row: 7px status dot + name (13px / 400 / `--fg`) + path on a second line (10.5px mono / `--fg-subtle`).
- Bottom: Settings row pinned, separated by a top border.
- Collapsed mode: only the icon, `tooltip`/`title` on hover.

## Topbar

- 52px tall, `--line` bottom border.
- Sidebar-toggle icon button on the left.
- **Search field** (`⌘K`): `--bg-elev` background, no border, 30px tall, with the kbd chip on the right. Placeholder: "Search sessions, files, workspaces…".
- Right cluster: theme toggle (sun/moon icon), then a divider, then the user avatar (24×24 round, `--accent-soft` bg, single-letter initial in `--accent`) + name.

## Screens

### Home (`// home`)
- Greeting: "Good afternoon, Jonah." (replace with real name from session).
- Sub-copy line with one inline link to Workspaces.
- **Stats strip**: 3 columns separated by left borders, top + bottom hairline rules. Each: eyebrow → number (38px JetBrains Mono) → caption. The "Busy" number uses `--accent`; others use `--fg`.
  - Busy / Idle / Total active.
- **Recently active** list: eyebrow `// recently active` + tiny right-aligned `sorted: last used` mono label. Then rows of: status dot · name · agent chip · workspace path (mono, right-aligned, min-width 160) · age (mono, right-aligned, min-width 36). Row hover gives `--bg-hover`.

### Workspaces (`// workspaces`)
- H1 + sub-copy with `/data-root` shown as an inline mono pill (1px hairline, `--bg-elev`).
- Top-right: "Add workspace" primary button.
- Groups: each labelled with eyebrow `// ews`, `// iib`, `// personal`, plus a count.
- 2-column grid of workspace cards. Card: 10px radius, `--bg-elev`, no border. Color-coded 3px left bar (workspace color). Inside: 28×28 folder icon block tinted with the workspace color (22% opacity background). Title (14px / 550), path on second line (mono / 11.5px / `--fg-subtle`). Bottom row: agent chip + "default agent" muted mono caption. Hover icon cluster on the right (edit / archive / trash) at 0.6 opacity.

### Workspace detail
- Breadcrumb: `← workspaces / personal / nova-tab` (mono, 12px).
- Title block: 42×42 colored folder square + "Personal / Nova Tab" with the parent dimmed.
- **Tabs:** Sessions · Files · Git · Rules. Active tab has `--accent` underline.
- **Sessions tab:** session count + view-mode segmented toggle (list/grid) + "New orchestrator" + primary "New session". Rows show checkbox · title · 1-line preview (subtle) · age (mono) · agent chip · hover action cluster.
- **Files tab:** 280px file tree column + preview pane (`--bg-elev`, centered "select a file to preview" empty state). Tree items in JetBrains Mono 12.5px.
- **Git tab:** "Changed files" header bar with count, refresh. Rows: checkbox · M/A/D status badge (warn/success/danger tinted square) · mono path. Commit message input on a flat `--bg-elev` bar — no visible field border. Primary "Commit (n)" + secondary "Push".

### Session / Chat
- Two-column inside main: 260px sessions rail · chat panel (`--bg-elev`, 12px radius).
- Sessions rail: back link + new-session icon button; mono group label "Nova Tab"; session cards. Active card has `--bg-elev` bg AND the 2px `--accent` left bar.
- Chat header: 14×14 panel icon · title (14 / 600) + "Nova Tab · claude" mono subline · edit / archive / trash icon cluster.
- Messages: 26×26 avatar square (mono initial, agent-tinted bg). Name + "· N ago" mono caption. Body in a `--bg-elev-2` bubble, 8px radius, 12×14 padding.
- **Composer**: `--bg-elev-2` rounded box, textarea is borderless and transparent. Footer row: paperclip icon · model mono caption (`claude-sonnet-4 · 128k`) · spacer · `⌘ ↵` kbd chips · primary send icon button.
- **Bottom mode switch** (chat / files / git): segmented control centered in the panel footer.

### Automations (`// automations`)
- Two-column: list (left) + run history panel (right, 360px).
- Card: title + active chip + agent chip + icon cluster. Mono meta line: `ws X · every 1w · next in 2d · last 17.4.2026, 12:27:47`. Then the prompt preview in `--fg-subtle`.
- Run history: header "WKZ Code Refactor — Runs · 2 runs". Each run: green check + timestamp · duration mono · chevron.
- "Edit automation" modal — see Modals.

### Settings (`// settings`)
**Tabs (top): General · Git · Integrations · MCP** — these match the live app exactly. The new "Themes" artboard is a separate explored direction; ship General / Git as below.

**General tab** (re-skinned but same options):
- **Appearance** section (`SECTION` eyebrow):
  - Row: "Automatic dark / light mode" + description, toggle on right.
  - Row: "Auto-continue Claude conversations" + description, toggle on right.
- **Dark Theme** section (with a moon icon next to the eyebrow): 4-col grid of swatches — Deep Space (active), Carbon, Terminal Green, Midnight Violet, Ember, Bloodline, OLED, Infrared. Each swatch has 3 small color dots, a name, and an active dot in the top-right when selected.
- **Light Theme** section (sun icon): Cloud (active), Cream, Frost, Sakura.
- **Notifications** section: "Task completion notifications" row with description + toggle.
- **Agent Authentication** section:
  - Cursor card — description with inline mono `cursor-agent login` chip; "Authenticated" success chip (green dot); Logout button + "View account & usage →" accent link.
  - Claude Code card — inline mono `claude setup-token` chip; Configured chip; Logout + "Manage account & usage →".
  - Mistral Vibe card — inline mono `~/.vibe/.env` chip; Configured chip; primary "Update API key" button (`--accent` background, white text); footer line "Get your key from Mistral Console." with accent link.

**Row treatment** (instead of bordered cards stacked together): each preference is its own `--bg-elev` panel at 10px radius, 14×16 padding, in a column with 8px gap. Title at 13.5 / 550, description at 12.5 / `--fg-subtle`. Toggle / select aligned center-right.

### Modals
- 12px radius, `--bg-elev-2` background, `0 24px 60px rgba(0,0,0,.6)` shadow + 1px `--line-strong` ring.
- Header: eyebrow `// add workspace` (etc.) + 16px / 600 title; close icon top-right.
- Form fields use `Field` wrapper: eyebrow label + input. Inputs are 34px tall, `--bg-elev` background, 1px `--line` border, focus border `--accent-line`.
- **Add Workspace** modal: name, group select, tags input, project path (mono input + Browse button), color picker (6 dots, selected has 2px ring), default agent segmented control. Primary "Create workspace".
- **New Session** modal: name, tags input + helper line, agent segmented control (3 options, agent-tinted when selected). Primary "Create".
- **Edit Automation** modal: name, agent select, interval select, enabled checkbox, prompt textarea. Save / Cancel.
- Backdrop: `color-mix(in oklab, var(--bg) 75%, transparent)` + `backdrop-filter: blur(4px)`.

## Iconography
Inline SVGs at 24×24 viewBox, 1.6px stroke, `currentColor`. The set used is small and consistent — avoid mixing in any third-party icon library. Common icons: home, folder, clock (automations), ruler (rules), search, settings, plus, edit, archive, trash, bolt, chart, grid, list, chev_right/left/down, arrow_left, send, paperclip, git, files, check, x, terminal, sparkle, refresh, expand, sun, moon, panel, sidebar, command.

## Behavior to keep (no change)

- All current tabs in Settings: **General, Git, Integrations, MCP**.
- All current settings options in General — toggles, theme grid (8 dark + 4 light), Notifications, Agent Authentication for Cursor / Claude Code / Mistral Vibe.
- Workspace tabs: Sessions / Files / Git / Rules.
- Session bottom mode switch: Chat / Files / Git.
- New-session and Add-workspace flows.
- Automation scheduling, run history, edit flow.
- Sidebar collapse state should persist per user.

## Files in this bundle

- `Nova Code Rework.html` — entry. Mounts the design canvas with every screen.
- `styles/tokens.css` — full token system, base type, button/input/chip/toggle classes.
- `design-canvas.jsx` — canvas wrapper used to lay out the artboards (not part of the app — it's the presentation surface only).
- `components/shell.jsx` — `NCShell`, `NCSidebar`, `NCTopbar`, `NCIcon`, `NCLogo`. Reusable shell.
- `components/screens-a.jsx` — Home, Workspaces, Workspace detail (Sessions/Files/Git tabs).
- `components/screens-b.jsx` — Automations, Session/Chat, modals (Add Workspace, New Session, Edit Automation).
- `components/screens-c.jsx` — Settings (General with Appearance / Dark Theme / Light Theme / Notifications / Agent Authentication, plus Git tab and the Themes exploration).

## Implementation notes for Claude Code

1. **Start with tokens.** Port `styles/tokens.css` into the app's existing CSS / SCSS / Tailwind config. The whole design depends on those custom properties; do not hardcode colors in components.
2. **`data-theme="dark"|"light"` on the root** is the only theme switch — no class toggling. The "Automatic dark/light mode" toggle in Settings should match `prefers-color-scheme` when on.
3. **Replace borders with spacing** when migrating from the current UI. If you find yourself reaching for a border, ask whether a row hover, an eyebrow label, or extra padding would do the job.
4. **Sidebar:** the active-row left bar (`2px × calc(100% - 16px) at left: -10px`) is the visual signature — keep it.
5. **Mono first-class.** Anywhere we currently show paths, file names, durations, timestamps, agent names, model identifiers, or commit hashes — switch to JetBrains Mono.
6. **Agent identity colors** (`--agent-claude/-cursor/-vibe`) should flow into chips, message avatars, and any agent-segmented controls. Don't introduce new accent colors per agent; reuse these.
7. **Modals:** flat surfaces, eyebrow + title, no chrome around the close icon.
8. **Functionality is sacred.** If the new design appears to drop a setting, an action, or a state, that's a bug in the design — surface it and re-add. Preserve every current option.
