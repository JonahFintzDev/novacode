// Screens 1: Home, Workspaces, Workspace detail (Sessions/Files/Git)

// ───────────────────── HOME ─────────────────────
function ScrHome({ theme, setTheme, collapsed, setCollapsed }) {
  const recent = [
    { name: 'Session 21/04/2026, 16:21:53', ws: 'project-management', ago: '5h', status: 'busy', agent: 'claude' },
    { name: 'CI',          ws: 'project-management', ago: '5h', status: 'idle', agent: 'cursor' },
    { name: 'Person',      ws: 'project-management', ago: '5h', status: 'idle', agent: 'claude' },
    { name: 'Fixes',       ws: 'project-management', ago: '6h', status: 'idle', agent: 'vibe' },
    { name: 'Invitation',  ws: 'project-management', ago: '7h', status: 'idle', agent: 'claude' },
    { name: 'Offline API', ws: 'project-management', ago: '7h', status: 'idle', agent: 'cursor' },
    { name: 'Top Bar',     ws: 'project-management', ago: '7h', status: 'idle', agent: 'claude' },
    { name: 'Rework',      ws: 'project-management', ago: '8h', status: 'idle', agent: 'vibe' },
    { name: 'New File',    ws: 'Nova Code',          ago: '9h', status: 'idle', agent: 'claude' },
    { name: 'Errors',      ws: 'project-management', ago: '10h', status: 'idle', agent: 'cursor' },
  ];

  return (
    <NCShell active="home" collapsed={collapsed} setCollapsed={setCollapsed} theme={theme} setTheme={setTheme} sessions={SAMPLE_SESSIONS}>
      <div style={{ maxWidth: 1040 }}>
        <div className="eyebrow" style={{ marginBottom: 10 }}>// home</div>
        <h1 className="h-page" style={{ margin: 0 }}>Good afternoon, Jonah.</h1>
        <p className="muted" style={{ margin: '6px 0 0', fontSize: 14 }}>
          Session activity across workspaces. Open <a style={{ color: 'var(--accent)', textDecoration: 'none', borderBottom: '1px solid var(--accent-line)' }}>Workspaces</a> to add projects or manage folders.
        </p>

        {/* stats — minimal, typographic, no boxes */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 0, marginTop: 36, borderTop: '1px solid var(--line)', borderBottom: '1px solid var(--line)' }}>
          {[
            { label: 'Busy',        value: '0',  sub: 'agents processing a prompt', accent: true },
            { label: 'Idle',        value: '87', sub: 'sessions ready for input' },
            { label: 'Total active', value: '87', sub: 'non-archived sessions' },
          ].map((s, i) => (
            <div key={i} style={{
              padding: '22px 28px 22px 0',
              borderLeft: i === 0 ? 'none' : '1px solid var(--line)',
              paddingLeft: i === 0 ? 0 : 28,
            }}>
              <div className="eyebrow" style={{ marginBottom: 10 }}>{s.label}</div>
              <div style={{
                fontSize: 38, fontWeight: 500, letterSpacing: '-0.03em', lineHeight: 1,
                color: s.accent ? 'var(--accent)' : 'var(--fg)',
                fontFamily: "'JetBrains Mono', monospace",
              }}>{s.value}</div>
              <div className="subtle" style={{ fontSize: 12.5, marginTop: 8 }}>{s.sub}</div>
            </div>
          ))}
        </div>

        {/* recent */}
        <div style={{ marginTop: 40 }}>
          <div style={{ display: 'flex', alignItems: 'baseline', marginBottom: 12 }}>
            <div className="eyebrow">// recently active</div>
            <span style={{ flex: 1 }} />
            <span className="mono subtle" style={{ fontSize: 11.5 }}>sorted: last used</span>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column' }}>
            {recent.map((r, i) => (
              <div key={i} className="row-hover" style={{
                display: 'flex', alignItems: 'center', gap: 14,
                padding: '11px 10px 11px 4px',
                borderRadius: 6,
                cursor: 'pointer',
              }}>
                <span className={`status-dot ${r.status}`} />
                <div style={{ flex: 1, minWidth: 0, display: 'flex', alignItems: 'baseline', gap: 10 }}>
                  <span style={{ fontSize: 13.5, fontWeight: 450, color: 'var(--fg)' }}>{r.name}</span>
                </div>
                <span className={`chip agent-${r.agent}`}>{r.agent}</span>
                <span className="mono subtle" style={{ fontSize: 12, minWidth: 160, textAlign: 'right' }}>{r.ws}</span>
                <span className="mono subtle" style={{ fontSize: 12, minWidth: 36, textAlign: 'right' }}>{r.ago}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </NCShell>
  );
}

// ───────────────────── WORKSPACES ─────────────────────
function WSCard({ name, path, color, agent }) {
  return (
    <div className="row-hover" style={{
      position: 'relative',
      background: 'var(--bg-elev)',
      borderRadius: 10,
      padding: '16px 18px',
      cursor: 'pointer',
      display: 'flex', flexDirection: 'column', gap: 14,
      minHeight: 110,
      overflow: 'hidden',
    }}>
      <div style={{ position: 'absolute', left: 0, top: 16, bottom: 16, width: 3, background: color, borderRadius: 2 }} />
      <div style={{ display: 'flex', alignItems: 'flex-start', gap: 10 }}>
        <div style={{
          width: 28, height: 28, borderRadius: 7,
          background: `color-mix(in oklab, ${color} 22%, transparent)`,
          color: color,
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          flexShrink: 0,
        }}>
          <NCIcon name="folder" size={14} />
        </div>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontSize: 14, fontWeight: 550, letterSpacing: '-0.01em' }}>{name}</div>
          <div className="mono subtle" style={{ fontSize: 11.5, marginTop: 2, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{path}</div>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 2, opacity: 0.6 }}>
          <button className="btn ghost icon sm"><NCIcon name="edit" size={13} /></button>
          <button className="btn ghost icon sm"><NCIcon name="archive" size={13} /></button>
          <button className="btn ghost icon sm danger"><NCIcon name="trash" size={13} /></button>
        </div>
      </div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginTop: 'auto' }}>
        <span className={`chip agent-${agent}`}>{agent}</span>
        <span className="mono subtle" style={{ fontSize: 11 }}>· default agent</span>
      </div>
    </div>
  );
}

function ScrWorkspaces({ theme, setTheme, collapsed, setCollapsed }) {
  const groups = [
    { id: 'EWS', workspaces: [
      { name: 'Delta Flow',      path: 'ews/delta-flow',     color: '#7aa2ff', agent: 'claude' },
      { name: 'WKZ | Input Tool', path: 'ews/wkz/input-tool', color: '#a78bfa', agent: 'claude' },
      { name: 'Dreh.info',       path: 'ews/dreh.info',      color: '#7ec994', agent: 'claude' },
      { name: 'Captcha Training',path: 'ews/wkz/captcha-model', color: '#e87676', agent: 'claude' },
      { name: 'project-management', path: 'ews/tools/project-management', color: '#8b85ff', agent: 'claude' },
    ]},
    { id: 'IIB', workspaces: [
      { name: 'Regio Atlas',     path: 'iib/regio-atlas',    color: '#e6b067', agent: 'cursor' },
      { name: 'GMA',             path: 'iib/gma',            color: '#a78bfa', agent: 'cursor' },
    ]},
  ];

  return (
    <NCShell active="workspaces" collapsed={collapsed} setCollapsed={setCollapsed} theme={theme} setTheme={setTheme} sessions={SAMPLE_SESSIONS}>
      <div style={{ maxWidth: 1040 }}>
        <div style={{ display: 'flex', alignItems: 'flex-start', gap: 12 }}>
          <div style={{ flex: 1 }}>
            <div className="eyebrow" style={{ marginBottom: 10 }}>// workspaces</div>
            <h1 className="h-page" style={{ margin: 0 }}>Workspaces</h1>
            <p className="muted" style={{ margin: '6px 0 0', fontSize: 14 }}>
              Select a workspace to browse files and manage git. Paths are under <span className="mono" style={{ color: 'var(--fg)', background: 'var(--bg-elev)', padding: '1px 6px', borderRadius: 4, fontSize: 12 }}>/data-root</span>.
            </p>
          </div>
          <button className="btn primary"><NCIcon name="plus" size={13} />Add workspace</button>
        </div>

        {groups.map((g, gi) => (
          <div key={g.id} style={{ marginTop: 40 }}>
            <div style={{ display: 'flex', alignItems: 'baseline', gap: 10, marginBottom: 14 }}>
              <div className="eyebrow">// {g.id.toLowerCase()}</div>
              <span className="mono subtle" style={{ fontSize: 11 }}>{g.workspaces.length} workspace{g.workspaces.length === 1 ? '' : 's'}</span>
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, minmax(0, 1fr))', gap: 14 }}>
              {g.workspaces.map((w, i) => <WSCard key={i} {...w} />)}
            </div>
          </div>
        ))}
      </div>
    </NCShell>
  );
}

// ───────────────────── WORKSPACE DETAIL ─────────────────────
function ScrWorkspace({ theme, setTheme, collapsed, setCollapsed, tab = 'sessions' }) {
  const tabs = [
    { id: 'sessions', label: 'Sessions', icon: 'list' },
    { id: 'files',    label: 'Files',    icon: 'files' },
    { id: 'git',      label: 'Git',      icon: 'git' },
    { id: 'rules',    label: 'Rules',    icon: 'ruler' },
  ];

  return (
    <NCShell active="workspaces" collapsed={collapsed} setCollapsed={setCollapsed} theme={theme} setTheme={setTheme} sessions={SAMPLE_SESSIONS}>
      <div style={{ maxWidth: 1040 }}>
        {/* breadcrumb */}
        <div className="mono" style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 12, color: 'var(--fg-subtle)', marginBottom: 18 }}>
          <NCIcon name="arrow_left" size={12} />
          <a style={{ color: 'var(--fg-muted)', cursor: 'pointer' }}>workspaces</a>
          <span>/</span>
          <span style={{ color: 'var(--fg)' }}>personal / nova-tab</span>
        </div>

        <div style={{ display: 'flex', alignItems: 'flex-start', gap: 14 }}>
          <div style={{
            width: 42, height: 42, borderRadius: 10,
            background: 'var(--accent-soft)',
            color: 'var(--accent)',
            display: 'flex', alignItems: 'center', justifyContent: 'center',
            flexShrink: 0,
          }}>
            <NCIcon name="folder" size={18} />
          </div>
          <div style={{ flex: 1 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <h1 className="h-page" style={{ margin: 0 }}>Personal</h1>
              <span className="subtle" style={{ fontSize: 20, fontWeight: 300 }}>/</span>
              <h1 className="h-page" style={{ margin: 0, color: 'var(--fg-muted)', fontWeight: 500 }}>Nova Tab</h1>
            </div>
            <div className="mono subtle" style={{ fontSize: 12, marginTop: 4 }}>personal/better-startpage</div>
          </div>
        </div>

        {/* tabs */}
        <div className="tabs" style={{ marginTop: 24 }}>
          {tabs.map((t) => (
            <div key={t.id} className={`tab ${t.id === tab ? 'active' : ''}`}>
              <NCIcon name={t.icon} size={13} /> {t.label}
            </div>
          ))}
        </div>

        {tab === 'sessions' && <WorkspaceSessions />}
        {tab === 'files' && <WorkspaceFiles />}
        {tab === 'git' && <WorkspaceGit />}
      </div>
    </NCShell>
  );
}

function WorkspaceSessions() {
  const rows = [
    { name: 'Design rework', ago: '4d ago', agent: 'claude', preview: 'Clean build, zero errors. Summary of every change…' },
    { name: 'Session 02/04/2026, 22:42:54', ago: '19d ago', agent: 'vibe', preview: 'Task completed.' },
  ];
  return (
    <div style={{ paddingTop: 24 }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 14 }}>
        <span className="mono subtle" style={{ fontSize: 11.5 }}>{rows.length} session{rows.length === 1 ? '' : 's'}</span>
        <span style={{ flex: 1 }} />
        <div style={{ display: 'flex', gap: 2, background: 'var(--bg-elev)', borderRadius: 6, padding: 2 }}>
          <button className="btn ghost icon sm" style={{ background: 'var(--bg-elev-2)' }}><NCIcon name="list" size={13} /></button>
          <button className="btn ghost icon sm"><NCIcon name="grid" size={13} /></button>
        </div>
        <button className="btn sm"><NCIcon name="terminal" size={13} />New orchestrator</button>
        <button className="btn primary sm"><NCIcon name="plus" size={13} />New session</button>
      </div>
      <div style={{ display: 'flex', flexDirection: 'column' }}>
        {rows.map((r, i) => (
          <div key={i} className="row-hover" style={{
            display: 'flex', alignItems: 'center', gap: 14,
            padding: '14px 12px',
            borderRadius: 8,
            cursor: 'pointer',
            borderBottom: i === rows.length - 1 ? 'none' : '1px solid var(--line)',
          }}>
            <input type="checkbox" style={{ accentColor: 'var(--accent)', flexShrink: 0 }} />
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontSize: 13.5, fontWeight: 500, color: 'var(--fg)' }}>{r.name}</div>
              <div className="subtle" style={{ fontSize: 12, marginTop: 2, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{r.preview}</div>
            </div>
            <span className="mono subtle" style={{ fontSize: 11.5 }}>{r.ago}</span>
            <span className={`chip agent-${r.agent}`}>{r.agent}</span>
            <div style={{ display: 'flex', gap: 2, opacity: .6 }}>
              <button className="btn ghost icon sm"><NCIcon name="edit" size={13} /></button>
              <button className="btn ghost icon sm"><NCIcon name="archive" size={13} /></button>
              <button className="btn ghost icon sm danger"><NCIcon name="trash" size={13} /></button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function WorkspaceFiles() {
  const tree = [
    { type: 'dir',  name: 'api' },
    { type: 'dir',  name: 'deploy' },
    { type: 'dir',  name: 'docs' },
    { type: 'dir',  name: 'extension' },
    { type: 'file', name: '.gitignore' },
    { type: 'file', name: 'APPLICATION_FUNCTIONS.md' },
    { type: 'file', name: 'dev.docker-compose.yaml' },
    { type: 'file', name: 'docker-compose-prod.yaml' },
    { type: 'file', name: 'migrate-db.sh' },
    { type: 'file', name: 'novatab.code-workspace' },
    { type: 'file', name: 'package-lock.json' },
    { type: 'file', name: 'README.md' },
  ];
  return (
    <div style={{ paddingTop: 24, display: 'grid', gridTemplateColumns: '280px 1fr', gap: 20 }}>
      <div>
        <div style={{ display: 'flex', alignItems: 'center', marginBottom: 10 }}>
          <div className="eyebrow">// files</div>
          <span style={{ flex: 1 }} />
          <button className="btn ghost icon sm"><NCIcon name="refresh" size={13} /></button>
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 1 }}>
          {tree.map((f, i) => (
            <div key={i} className="row-hover" style={{
              display: 'flex', alignItems: 'center', gap: 8,
              padding: '6px 10px', borderRadius: 5, cursor: 'pointer',
              color: f.type === 'dir' ? 'var(--fg)' : 'var(--fg-muted)',
              fontSize: 13,
            }}>
              {f.type === 'dir' ? <NCIcon name="chev_right" size={11} /> : <span style={{ width: 11 }} />}
              <span style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: 12.5 }}>{f.name}</span>
            </div>
          ))}
        </div>
      </div>
      <div style={{
        background: 'var(--bg-elev)', borderRadius: 8,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        minHeight: 400, color: 'var(--fg-subtle)',
        fontFamily: "'JetBrains Mono', monospace", fontSize: 12,
      }}>
        <div style={{ textAlign: 'center' }}>
          <NCIcon name="files" size={28} />
          <div style={{ marginTop: 10 }}>select a file to preview</div>
        </div>
      </div>
    </div>
  );
}

function WorkspaceGit() {
  const files = [
    '.gitea/workflows/deploy.yaml',
    '.gitignore',
    'README.md',
    'api/Data/HTML/RegistrationError.html',
    'api/Data/HTML/RegistrationSuccess.html',
    'api/Data/Mail/EmailValidation.html',
    'api/Data/Mail/EmailValidation.json',
    'api/Data/Mail/PasswordReset.html',
    'api/Data/Mail/PasswordReset.json',
    'api/docker-entrypoint.sh',
    'api/package-lock.json',
    'api/package.json',
    'api/prisma/migrations/20250221165216_init/migration.sql',
  ];
  return (
    <div style={{ paddingTop: 24 }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 14, padding: '10px 12px', background: 'var(--bg-elev)', borderRadius: 8 }}>
        <input type="checkbox" defaultChecked style={{ accentColor: 'var(--accent)' }} />
        <div style={{ fontSize: 13, fontWeight: 500 }}>Changed files</div>
        <span className="mono subtle" style={{ fontSize: 11.5 }}>170</span>
        <span style={{ flex: 1 }} />
        <button className="btn ghost icon sm"><NCIcon name="refresh" size={13} /></button>
      </div>
      <div style={{ display: 'flex', flexDirection: 'column', gap: 1 }}>
        {files.map((f, i) => (
          <div key={i} className="row-hover" style={{
            display: 'flex', alignItems: 'center', gap: 10,
            padding: '8px 12px', borderRadius: 6, cursor: 'pointer',
          }}>
            <input type="checkbox" defaultChecked style={{ accentColor: 'var(--accent)' }} />
            <span style={{
              width: 18, height: 18, borderRadius: 4,
              background: 'color-mix(in oklab, var(--warn) 18%, transparent)',
              color: 'var(--warn)',
              fontSize: 10.5, fontWeight: 600,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              fontFamily: "'JetBrains Mono', monospace",
            }}>M</span>
            <span className="mono" style={{ fontSize: 12.5, color: 'var(--fg-muted)' }}>{f}</span>
          </div>
        ))}
      </div>
      <div style={{ marginTop: 18, padding: 12, background: 'var(--bg-elev)', borderRadius: 8 }}>
        <input className="input" placeholder="Commit message…" style={{ background: 'transparent', border: 'none', padding: 0, height: 28 }} />
      </div>
      <div style={{ display: 'flex', gap: 8, marginTop: 12 }}>
        <button className="btn primary"><NCIcon name="check" size={13} />Commit (170)</button>
        <button className="btn"><NCIcon name="bolt" size={13} />Push</button>
      </div>
    </div>
  );
}

Object.assign(window, { ScrHome, ScrWorkspaces, ScrWorkspace });
