// Screens 2: Automations, Session/Chat, Settings, Modals

// ───────── AUTOMATIONS ─────────
function ScrAutomations({ theme, setTheme, collapsed, setCollapsed, showEditModal }) {
  const autos = [
    { name: 'WKZ Code Refactor', agent: 'vibe', ws: 'Nova Code',
      every: '1w', next: '2d', last: '17.4.2026, 12:27:47',
      prompt: 'Update all Files according to the coding guidelines in /data-root/personal/CO…', active: true },
    { name: 'Daily Code Refactor', agent: 'cursor', ws: 'Nova Code',
      every: '1d', next: '15h 18m', last: '21.4.2026, 14:12:17',
      prompt: 'Do a code refactor according to /data-root/personal/CODING_CONVENTION…', active: true },
  ];

  return (
    <NCShell active="automations" collapsed={collapsed} setCollapsed={setCollapsed} theme={theme} setTheme={setTheme} sessions={SAMPLE_SESSIONS}>
      <div style={{ maxWidth: 1040, position: 'relative' }}>
        <div style={{ display: 'flex', alignItems: 'flex-start', gap: 12 }}>
          <div style={{ flex: 1 }}>
            <div className="eyebrow" style={{ marginBottom: 10 }}>// automations</div>
            <h1 className="h-page" style={{ margin: 0 }}>Automations</h1>
            <p className="muted" style={{ margin: '6px 0 0', fontSize: 14 }}>
              Schedule AI agents to run automatically at a set interval and review their reports.
            </p>
          </div>
          <button className="btn primary"><NCIcon name="plus" size={13} />New automation</button>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 360px', gap: 20, marginTop: 32 }}>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            {autos.map((a, i) => (
              <div key={i} style={{
                background: 'var(--bg-elev)', borderRadius: 10, padding: '16px 18px',
                display: 'flex', flexDirection: 'column', gap: 10,
              }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                  <div style={{ fontSize: 14, fontWeight: 600 }}>{a.name}</div>
                  {a.active && <span className="chip success dot">active</span>}
                  <span className={`chip agent-${a.agent}`}>{a.agent}</span>
                  <span style={{ flex: 1 }} />
                  <div style={{ display: 'flex', gap: 2 }}>
                    <button className="btn ghost icon sm"><NCIcon name="chart" size={13} /></button>
                    <button className="btn ghost icon sm"><NCIcon name="bolt" size={13} /></button>
                    <button className="btn ghost icon sm"><NCIcon name="edit" size={13} /></button>
                    <button className="btn ghost icon sm danger"><NCIcon name="trash" size={13} /></button>
                  </div>
                </div>
                <div className="mono" style={{ fontSize: 11.5, color: 'var(--fg-subtle)', display: 'flex', gap: 14 }}>
                  <span><span style={{ color: 'var(--fg-faint)' }}>ws</span> {a.ws}</span>
                  <span><span style={{ color: 'var(--fg-faint)' }}>every</span> {a.every}</span>
                  <span><span style={{ color: 'var(--fg-faint)' }}>next</span> in {a.next}</span>
                  <span><span style={{ color: 'var(--fg-faint)' }}>last</span> {a.last}</span>
                </div>
                <div className="subtle" style={{ fontSize: 12.5, lineHeight: 1.5 }}>{a.prompt}</div>
              </div>
            ))}
          </div>

          <div style={{
            background: 'var(--bg-elev)', borderRadius: 10, padding: 0,
            display: 'flex', flexDirection: 'column',
            alignSelf: 'start',
            minHeight: 280,
          }}>
            <div style={{ padding: '14px 16px', borderBottom: '1px solid var(--line)', display: 'flex', alignItems: 'center' }}>
              <div style={{ fontSize: 13, fontWeight: 500 }}>WKZ Code Refactor — Runs</div>
              <span style={{ flex: 1 }} />
              <span className="mono subtle" style={{ fontSize: 11 }}>2 runs</span>
            </div>
            {['17.4.2026, 12:27:47', '17.4.2026, 12:27:27'].map((t, i) => (
              <div key={i} className="row-hover" style={{
                padding: '12px 16px', display: 'flex', alignItems: 'center', gap: 10,
                borderBottom: i === 0 ? '1px solid var(--line)' : 'none',
              }}>
                <NCIcon name="check" size={12} style={{ color: 'var(--success)' }} />
                <div className="mono" style={{ fontSize: 12, color: 'var(--fg)' }}>{t}</div>
                <span style={{ flex: 1 }} />
                <span className="mono subtle" style={{ fontSize: 11 }}>{i === 0 ? '1002s' : '958s'}</span>
                <NCIcon name="chev_down" size={12} />
              </div>
            ))}
          </div>
        </div>

        {showEditModal && <EditAutomationModal />}
      </div>
    </NCShell>
  );
}

function EditAutomationModal() {
  return (
    <div style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'flex-start', justifyContent: 'center',
      paddingTop: 80, background: 'color-mix(in oklab, var(--bg) 70%, transparent)', backdropFilter: 'blur(4px)', zIndex: 10,
    }}>
      <div style={{
        width: 520, background: 'var(--bg-elev-2)', borderRadius: 12,
        boxShadow: '0 24px 60px rgba(0,0,0,0.6), 0 0 0 1px var(--line-strong)',
        padding: 22,
      }}>
        <div style={{ display: 'flex', alignItems: 'center', marginBottom: 18 }}>
          <div>
            <div className="eyebrow" style={{ marginBottom: 4 }}>// edit automation</div>
            <div style={{ fontSize: 16, fontWeight: 600 }}>WKZ Code Refactor</div>
          </div>
          <span style={{ flex: 1 }} />
          <button className="btn ghost icon sm"><NCIcon name="x" size={14} /></button>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
          <Field label="Name"><input className="input" defaultValue="WKZ Code Refactor" /></Field>
          <Field label="Agent"><select className="input" defaultValue="vibe">
            <option>cursor</option><option>vibe</option><option>claude</option>
          </select></Field>
          <Field label="Interval"><select className="input" defaultValue="1w">
            <option>1 day</option><option>7 days (weekly)</option>
          </select></Field>
          <div style={{ display: 'flex', alignItems: 'end' }}>
            <label style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 13, color: 'var(--fg-muted)', cursor: 'pointer' }}>
              <input type="checkbox" defaultChecked style={{ accentColor: 'var(--accent)' }} /> Enabled
            </label>
          </div>
        </div>
        <div style={{ marginTop: 14 }}>
          <Field label="Prompt">
            <textarea className="input" rows={3} defaultValue="Update all Files according to the coding guidelines in /data-root/personal/CODING_CONVENTIONS.md" />
          </Field>
        </div>
        <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 8, marginTop: 18 }}>
          <button className="btn ghost">Cancel</button>
          <button className="btn primary">Save</button>
        </div>
      </div>
    </div>
  );
}

function Field({ label, children }) {
  return (
    <label style={{ display: 'block' }}>
      <div className="eyebrow" style={{ marginBottom: 6 }}>{label}</div>
      {children}
    </label>
  );
}

// ───────── SESSION / CHAT ─────────
function ScrSession({ theme, setTheme, collapsed, setCollapsed, bottomTab = 'chat' }) {
  return (
    <NCShell active="workspaces" collapsed={collapsed} setCollapsed={setCollapsed} theme={theme} setTheme={setTheme} sessions={SAMPLE_SESSIONS}>
      <div style={{ display: 'grid', gridTemplateColumns: '260px 1fr', gap: 18, height: '100%' }}>
        {/* sessions rail */}
        <aside>
          <div style={{ display: 'flex', alignItems: 'center', marginBottom: 12 }}>
            <a className="mono" style={{ fontSize: 12, color: 'var(--fg-muted)', display: 'flex', alignItems: 'center', gap: 6 }}>
              <NCIcon name="arrow_left" size={12} /> sessions
            </a>
            <span style={{ flex: 1 }} />
            <button className="btn ghost icon sm"><NCIcon name="plus" size={13} /></button>
          </div>
          <div className="mono subtle" style={{ fontSize: 11, marginBottom: 10 }}>Nova Tab</div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
            {[
              { n: 'Design rework', ago: '4d ago', active: true, agent: 'claude', preview: 'Clean build, zero errors. Here\'s a summary of every…' },
              { n: 'Session 02/04/2026, 22:42:54', ago: '19d ago', agent: 'vibe', preview: 'Task completed. Task completed.' },
            ].map((s, i) => (
              <div key={i} style={{
                padding: '10px 12px', borderRadius: 8, cursor: 'pointer',
                background: s.active ? 'var(--bg-elev)' : 'transparent',
                position: 'relative',
              }} className={s.active ? '' : 'row-hover'}>
                {s.active && <div style={{ position: 'absolute', left: 0, top: 10, bottom: 10, width: 2, background: 'var(--accent)', borderRadius: 2 }} />}
                <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                  <span className={`chip agent-${s.agent}`} style={{ height: 18 }}>{s.agent}</span>
                  <span style={{ flex: 1 }} />
                  <span className="mono subtle" style={{ fontSize: 10.5 }}>{s.ago}</span>
                </div>
                <div style={{ fontSize: 13, fontWeight: 500, marginTop: 6 }}>{s.n}</div>
                <div className="subtle" style={{ fontSize: 11.5, marginTop: 3, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{s.preview}</div>
              </div>
            ))}
          </div>
        </aside>

        {/* chat pane */}
        <section style={{ display: 'flex', flexDirection: 'column', minWidth: 0, background: 'var(--bg-elev)', borderRadius: 12, padding: 0, overflow: 'hidden' }}>
          <div style={{ padding: '14px 18px', borderBottom: '1px solid var(--line)', display: 'flex', alignItems: 'center', gap: 10 }}>
            <NCIcon name="panel" size={14} style={{ color: 'var(--fg-muted)' }} />
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 14, fontWeight: 600 }}>Design rework</div>
              <div className="mono subtle" style={{ fontSize: 11 }}>Nova Tab · claude</div>
            </div>
            <button className="btn ghost icon sm"><NCIcon name="edit" size={13} /></button>
            <button className="btn ghost icon sm"><NCIcon name="archive" size={13} /></button>
            <button className="btn ghost icon sm danger"><NCIcon name="trash" size={13} /></button>
          </div>

          {bottomTab === 'chat' && <ChatBody />}
          {bottomTab === 'files' && <SessionFilesBody />}
          {bottomTab === 'git' && <div style={{ flex: 1, padding: 18 }}><WorkspaceGit /></div>}

          {/* bottom mode switch */}
          <div style={{ padding: '10px 18px', borderTop: '1px solid var(--line)', display: 'flex', justifyContent: 'center' }}>
            <div style={{ display: 'flex', gap: 2, background: 'var(--bg)', borderRadius: 8, padding: 3 }}>
              {['chat', 'files', 'git'].map((t) => (
                <div key={t} style={{
                  padding: '5px 14px', fontSize: 12, borderRadius: 6, cursor: 'pointer',
                  background: t === bottomTab ? 'var(--bg-elev-2)' : 'transparent',
                  color: t === bottomTab ? 'var(--fg)' : 'var(--fg-muted)',
                  textTransform: 'capitalize', fontWeight: 500,
                  display: 'flex', alignItems: 'center', gap: 6,
                }}>
                  <NCIcon name={t === 'chat' ? 'sparkle' : t === 'files' ? 'files' : 'git'} size={12} />
                  {t}
                </div>
              ))}
            </div>
          </div>
        </section>
      </div>
    </NCShell>
  );
}

function ChatBody() {
  return (
    <>
      <div style={{ flex: 1, overflowY: 'auto', padding: '20px 22px', display: 'flex', flexDirection: 'column', gap: 16 }}>
        <ChatMsg role="agent" agent="claude" body={(
          <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
            <div><span className="mono" style={{ color: 'var(--agent-claude)' }}>index.html</span> — Replaced Open Sans with Inter (Google Fonts).</div>
            <div><span className="mono" style={{ color: 'var(--agent-claude)' }}>themes.css</span> — Full color system overhaul: <code>#0c0c0c</code> app bg, <code>#161616</code> surfaces, <code>#1f1f1f</code> cards/inputs.</div>
            <div><span className="mono" style={{ color: 'var(--agent-claude)' }}>main.css</span> — Comprehensive rewrite:</div>
            <ul style={{ paddingLeft: 18, margin: 0, display: 'flex', flexDirection: 'column', gap: 4 }}>
              <li>Removed all <code>backdrop-filter: blur(0)</code> from topbar, sidebar, panels, modals.</li>
              <li>Topbar: <code>h-14 (56px)</code>, solid surface bg, no box-shadow.</li>
              <li>Sidebar: <code>w-56</code> open / <code>w-[72px]</code> closed (icon-only), solid bg.</li>
              <li>Sub-group cards: <code>w-80 (320px)</code>, rounded-2xl, solid <code>#1f1f1f</code> bg.</li>
            </ul>
            <div style={{ marginTop: 4 }}>
              <span className="mono" style={{ color: 'var(--agent-claude)' }}>GroupNavigation.vue</span> — Tab buttons changed from <code>btn btn-muted btn-md</code> to filled primary pill when active.
            </div>
            <div>Ready for review — all changes look consistent with the system.</div>
          </div>
        )} />
      </div>
      {/* composer */}
      <div style={{ padding: '14px 18px', borderTop: '1px solid var(--line)' }}>
        <div style={{
          background: 'var(--bg-elev-2)', borderRadius: 10,
          padding: '10px 12px',
          display: 'flex', flexDirection: 'column', gap: 6,
        }}>
          <textarea className="input" placeholder="Type a message… (Ctrl+Enter to send, Enter for newline)"
            style={{ border: 'none', background: 'transparent', padding: 0, minHeight: 40, fontSize: 13.5 }} />
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <button className="btn ghost icon sm"><NCIcon name="paperclip" size={13} /></button>
            <span className="mono subtle" style={{ fontSize: 10.5 }}>claude-sonnet-4 · 128k</span>
            <span style={{ flex: 1 }} />
            <span className="mono subtle" style={{ fontSize: 10.5, display: 'flex', alignItems: 'center', gap: 5 }}>
              <kbd className="k">⌘</kbd><kbd className="k">↵</kbd>
            </span>
            <button className="btn primary icon sm"><NCIcon name="send" size={12} /></button>
          </div>
        </div>
      </div>
    </>
  );
}

function ChatMsg({ role, agent, body }) {
  const me = role === 'user';
  return (
    <div style={{ display: 'flex', gap: 12, alignItems: 'flex-start', maxWidth: '100%' }}>
      <div style={{
        width: 26, height: 26, borderRadius: 7, flexShrink: 0,
        background: me ? 'var(--accent-soft)' : `color-mix(in oklab, var(--agent-${agent}) 22%, transparent)`,
        color: me ? 'var(--accent)' : `var(--agent-${agent})`,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        fontSize: 11, fontWeight: 600, fontFamily: "'JetBrains Mono', monospace",
      }}>{me ? 'J' : agent.charAt(0).toUpperCase()}</div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ display: 'flex', alignItems: 'baseline', gap: 8, marginBottom: 6 }}>
          <span style={{ fontSize: 12.5, fontWeight: 600 }}>{me ? 'You' : 'Claude'}</span>
          <span className="mono subtle" style={{ fontSize: 10.5 }}>{me ? '· just now' : '· 4d ago'}</span>
        </div>
        <div style={{
          fontSize: 13, lineHeight: 1.6, color: 'var(--fg)',
          background: 'var(--bg-elev-2)', padding: '12px 14px', borderRadius: 8,
        }}>
          {body}
        </div>
      </div>
    </div>
  );
}

function SessionFilesBody() {
  const tree = ['api','deploy','docs','extension','.gitignore','APPLICATION_FUNCTIONS.md','dev.docker-compose.yaml','docker-compose-prod.yaml','migrate-db.sh','novatab.code-workspace','package-lock.json','README.md','translate.py','UX_USER_FUNCTIONS.md'];
  return (
    <div style={{ flex: 1, display: 'grid', gridTemplateColumns: '260px 1fr', gap: 0, minHeight: 0 }}>
      <div style={{ padding: '14px 18px', borderRight: '1px solid var(--line)', overflowY: 'auto' }}>
        <div style={{ display: 'flex', alignItems: 'center', marginBottom: 10 }}>
          <div style={{ fontSize: 13, fontWeight: 600 }}>Files</div>
          <span style={{ flex: 1 }} />
          <button className="btn ghost icon sm"><NCIcon name="expand" size={12} /></button>
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 1 }}>
          {tree.map((f, i) => {
            const isDir = i < 4;
            return (
              <div key={i} className="row-hover" style={{
                display: 'flex', alignItems: 'center', gap: 8,
                padding: '5px 8px', borderRadius: 5,
                fontFamily: "'JetBrains Mono', monospace", fontSize: 12,
                color: isDir ? 'var(--fg)' : 'var(--fg-muted)',
              }}>
                {isDir ? <NCIcon name="chev_right" size={11} /> : <span style={{ width: 11 }} />}
                <span>{f}</span>
              </div>
            );
          })}
        </div>
      </div>
      <div style={{ padding: 18, color: 'var(--fg-subtle)', fontFamily: "'JetBrains Mono', monospace", fontSize: 12, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        select a file
      </div>
    </div>
  );
}

// ───────── MODALS: Add Workspace & New Session ─────────
function NewSessionModal() {
  const agents = ['cursor', 'vibe', 'claude'];
  const [sel, setSel] = React.useState('cursor');
  return (
    <div style={{ position: 'absolute', inset: 0, background: 'color-mix(in oklab, var(--bg) 75%, transparent)', backdropFilter: 'blur(4px)',
      display: 'flex', alignItems: 'flex-start', justifyContent: 'center', paddingTop: 120, zIndex: 10 }}>
      <div style={{ width: 440, background: 'var(--bg-elev-2)', borderRadius: 12, padding: 22,
        boxShadow: '0 24px 60px rgba(0,0,0,0.6), 0 0 0 1px var(--line-strong)' }}>
        <div style={{ display: 'flex', alignItems: 'center', marginBottom: 18 }}>
          <div>
            <div className="eyebrow" style={{ marginBottom: 4 }}>// new session</div>
            <div style={{ fontSize: 16, fontWeight: 600 }}>Start a session</div>
          </div>
          <span style={{ flex: 1 }} />
          <button className="btn ghost icon sm"><NCIcon name="x" size={14} /></button>
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          <Field label="Name"><input className="input" defaultValue="Session 21.4.2026, 22:54:01" /></Field>
          <Field label="Tags (optional)"><input className="input" placeholder="Add tag…" /></Field>
          <div className="subtle" style={{ fontSize: 11.5, marginTop: -8 }}>
            Separate tags with a comma, or press Enter/Done.
          </div>
          <Field label="Agent (required)">
            <div style={{ display: 'flex', gap: 6, background: 'var(--bg-elev)', padding: 4, borderRadius: 8 }}>
              {agents.map((a) => (
                <button key={a} onClick={() => setSel(a)} className="btn" style={{
                  flex: 1, border: 'none', background: sel === a ? 'var(--bg-elev-2)' : 'transparent',
                  color: sel === a ? `var(--agent-${a})` : 'var(--fg-muted)',
                  boxShadow: sel === a ? `inset 0 0 0 1px color-mix(in oklab, var(--agent-${a}) 40%, transparent)` : 'none',
                  textTransform: 'capitalize', fontWeight: 500,
                }}>
                  <NCIcon name="sparkle" size={12} /> {a}
                </button>
              ))}
            </div>
          </Field>
        </div>
        <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 8, marginTop: 20 }}>
          <button className="btn ghost">Cancel</button>
          <button className="btn primary">Create</button>
        </div>
      </div>
    </div>
  );
}

function AddWorkspaceModal() {
  const colors = ['#7aa2ff', '#a78bfa', '#7ec994', '#e6b067', '#e879b9', '#e87676'];
  const [sel, setSel] = React.useState(0);
  const [agent, setAgent] = React.useState('cursor');
  return (
    <div style={{ position: 'absolute', inset: 0, background: 'color-mix(in oklab, var(--bg) 75%, transparent)', backdropFilter: 'blur(4px)',
      display: 'flex', alignItems: 'flex-start', justifyContent: 'center', paddingTop: 36, zIndex: 10 }}>
      <div style={{ width: 520, background: 'var(--bg-elev-2)', borderRadius: 12, padding: 22,
        boxShadow: '0 24px 60px rgba(0,0,0,0.6), 0 0 0 1px var(--line-strong)' }}>
        <div style={{ display: 'flex', alignItems: 'center', marginBottom: 18 }}>
          <div>
            <div className="eyebrow" style={{ marginBottom: 4 }}>// add workspace</div>
            <div style={{ fontSize: 16, fontWeight: 600 }}>New workspace</div>
          </div>
          <span style={{ flex: 1 }} />
          <button className="btn ghost icon sm"><NCIcon name="x" size={14} /></button>
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          <Field label="Workspace name"><input className="input" placeholder="e.g. My Project" /></Field>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
            <Field label="Group">
              <select className="input"><option>Select a group…</option><option>EWS</option><option>IIB</option><option>Personal</option></select>
            </Field>
            <Field label="Tags">
              <input className="input" placeholder="Add tag…" />
            </Field>
          </div>
          <Field label="Project path">
            <div style={{ display: 'flex', gap: 6 }}>
              <input className="input mono" defaultValue="/my-project" />
              <button className="btn">Browse…</button>
            </div>
          </Field>
          <Field label="Color">
            <div style={{ display: 'flex', gap: 10, paddingTop: 4 }}>
              {colors.map((c, i) => (
                <div key={i} onClick={() => setSel(i)} style={{
                  width: 22, height: 22, borderRadius: 11, background: c, cursor: 'pointer',
                  border: sel === i ? '2px solid var(--fg)' : '2px solid transparent',
                  boxShadow: sel === i ? `0 0 0 1.5px var(--bg)` : 'none',
                }} />
              ))}
            </div>
          </Field>
          <Field label="Default agent">
            <div style={{ display: 'flex', gap: 6, background: 'var(--bg-elev)', padding: 4, borderRadius: 8 }}>
              {['cursor', 'vibe', 'claude'].map((a) => (
                <button key={a} onClick={() => setAgent(a)} className="btn" style={{
                  flex: 1, border: 'none', background: agent === a ? 'var(--bg-elev-2)' : 'transparent',
                  color: agent === a ? `var(--agent-${a})` : 'var(--fg-muted)',
                  textTransform: 'capitalize', fontWeight: 500,
                }}>{a}</button>
              ))}
            </div>
          </Field>
        </div>
        <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 8, marginTop: 20 }}>
          <button className="btn ghost">Cancel</button>
          <button className="btn primary"><NCIcon name="plus" size={12} />Create workspace</button>
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { ScrAutomations, ScrSession, NewSessionModal, AddWorkspaceModal, Field });
