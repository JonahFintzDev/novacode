// Settings — re-skinned to match the original Nova Code structure:
// Tabs: General · Git · Integrations · MCP
// General contains: Appearance (auto dark/light, auto-continue Claude),
// Dark Theme grid, Light Theme grid, Notifications, Agent Authentication.

function SettingsTabs({ active }) {
  const tabs = ['General', 'Git', 'Integrations', 'MCP'];
  return (
    <div className="tabs" style={{ marginTop: 6, marginBottom: 28 }}>
      {tabs.map((t) => (
        <div key={t} className={`tab ${t.toLowerCase() === active ? 'active' : ''}`}>{t}</div>
      ))}
    </div>
  );
}

function SettingsHeader() {
  return (
    <>
      <div className="eyebrow" style={{ marginBottom: 10 }}>// settings</div>
      <h1 className="h-page" style={{ margin: 0 }}>Settings</h1>
      <p className="muted" style={{ margin: '6px 0 0', fontSize: 14 }}>
        Configure agent authentication, appearance, and preferences.
      </p>
    </>
  );
}

function SectionLabel({ icon, children }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginTop: 36, marginBottom: 12 }}>
      {icon && <NCIcon name={icon} size={12} style={{ color: 'var(--fg-subtle)' }} />}
      <div className="eyebrow">{children}</div>
    </div>
  );
}

function Toggle({ on = false }) {
  return (
    <div style={{
      width: 34, height: 19, borderRadius: 10,
      background: on ? 'var(--accent)' : 'var(--line-strong)',
      padding: 2, position: 'relative', cursor: 'pointer', flexShrink: 0,
    }}>
      <div style={{
        width: 15, height: 15, borderRadius: 8,
        background: on ? '#fff' : 'var(--fg-muted)',
        transform: on ? 'translateX(15px)' : 'translateX(0)',
        transition: 'transform .15s',
      }} />
    </div>
  );
}

function PrefRow({ title, desc, children }) {
  return (
    <div style={{
      background: 'var(--bg-elev)', borderRadius: 10,
      padding: '14px 16px',
      display: 'flex', alignItems: 'center', gap: 18,
    }}>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontSize: 13.5, fontWeight: 550 }}>{title}</div>
        {desc && <div className="subtle" style={{ fontSize: 12.5, marginTop: 3, lineHeight: 1.5 }}>{desc}</div>}
      </div>
      {children}
    </div>
  );
}

function ThemeSwatch({ name, dots, active, dark }) {
  return (
    <div style={{
      padding: '12px 14px', borderRadius: 10, cursor: 'pointer',
      background: dark ? 'var(--bg-elev)' : 'var(--bg-elev-2)',
      boxShadow: active ? `inset 0 0 0 1.5px var(--accent)` : `inset 0 0 0 1px var(--line)`,
      position: 'relative',
    }}>
      <div style={{ display: 'flex', gap: 6, marginBottom: 18 }}>
        {dots.map((c, i) => (
          <div key={i} style={{ width: 16, height: 16, borderRadius: 8, background: c, border: '1px solid var(--line)' }} />
        ))}
      </div>
      <div style={{ fontSize: 13, fontWeight: 500 }}>{name}</div>
      {active && <div style={{
        position: 'absolute', top: 10, right: 10,
        width: 7, height: 7, borderRadius: 4, background: 'var(--accent)',
      }} />}
    </div>
  );
}

const DARK_THEMES = [
  { name: 'Deep Space',     dots: ['#0c0e16', '#5b8def', '#1a1d2e'], active: true },
  { name: 'Carbon',         dots: ['#0c0c0c', '#3a86ff', '#1a1a1a'] },
  { name: 'Terminal Green', dots: ['#0a120a', '#22c55e', '#162816'] },
  { name: 'Midnight Violet',dots: ['#0e0a18', '#a78bfa', '#1d1430'] },
  { name: 'Ember',          dots: ['#100a08', '#ef6c4a', '#2a1610'] },
  { name: 'Bloodline',      dots: ['#0a0606', '#e11d48', '#2a0e10'] },
  { name: 'OLED',           dots: ['#000000', '#ff2d6f', '#0a0a0a'] },
  { name: 'Infrared',       dots: ['#0a0608', '#ff5577', '#1a0e12'] },
];
const LIGHT_THEMES = [
  { name: 'Cloud',  dots: ['#ffffff', '#5b8def', '#e6ebf5'], active: true },
  { name: 'Cream',  dots: ['#ffffff', '#d97757', '#f5e9d4'] },
  { name: 'Frost',  dots: ['#ffffff', '#0ea5e9', '#dbeafe'] },
  { name: 'Sakura', dots: ['#ffffff', '#ec4899', '#fce7f0'] },
];

// New “Themes” tab content (kept from previous design — full theme cards)
const FULL_THEMES = [
  { name: 'Graphite (default)', accent: '#8b85ff', bg: '#0f0e0d', active: true },
  { name: 'Ember',              accent: '#ff8a4c', bg: '#100c0a' },
  { name: 'Terminal',           accent: '#7ec994', bg: '#0c0e0c' },
  { name: 'Cobalt',             accent: '#7aa2ff', bg: '#0a0c12' },
  { name: 'Mono',               accent: '#e5e5e5', bg: '#0a0a0a' },
  { name: 'Mojave (light)',     accent: '#4f48e6', bg: '#f6f3ec' },
];

function ScrSettingsGeneral({ theme, setTheme, collapsed, setCollapsed }) {
  return (
    <NCShell active="settings" collapsed={collapsed} setCollapsed={setCollapsed} theme={theme} setTheme={setTheme} sessions={SAMPLE_SESSIONS}>
      <div style={{ maxWidth: 1040 }}>
        <SettingsHeader />
        <SettingsTabs active="general" />

        <SectionLabel>Appearance</SectionLabel>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          <PrefRow title="Automatic dark / light mode"
            desc="Switches between your chosen dark and light themes based on your browser or OS preference.">
            <Toggle on />
          </PrefRow>
          <PrefRow title="Auto-continue Claude conversations"
            desc="Automatically continue conversations when Claude API limits reset.">
            <Toggle />
          </PrefRow>
        </div>

        <SectionLabel icon="moon">Dark Theme</SectionLabel>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 10 }}>
          {DARK_THEMES.map((t) => <ThemeSwatch key={t.name} {...t} dark />)}
        </div>

        <SectionLabel icon="sun">Light Theme</SectionLabel>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 10 }}>
          {LIGHT_THEMES.map((t) => <ThemeSwatch key={t.name} {...t} />)}
        </div>

        <SectionLabel>Notifications</SectionLabel>
        <PrefRow title="Task completion notifications"
          desc="Get a browser notification when an agent task finishes while the tab is in the background.">
          <Toggle />
        </PrefRow>

        <SectionLabel>Agent Authentication</SectionLabel>
        <p className="subtle" style={{ fontSize: 12.5, marginTop: -4, marginBottom: 12 }}>
          Log in to AI services. Credentials are stored in the config volume and persist across restarts.
        </p>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          <AuthCard
            name="Cursor"
            descPre="Uses "
            cmd="cursor-agent login"
            descPost=" — sign in with your Cursor account"
            status="Authenticated"
            primary={false}
            actionLabel="Logout"
            link="View account & usage →"
          />
          <AuthCard
            name="Claude Code"
            descPre="Uses "
            cmd="claude setup-token"
            descPost=" — sign in with your Claude account and paste the issued token into the terminal overlay."
            status="Configured"
            actionLabel="Logout"
            link="Manage account & usage →"
          />
          <AuthCard
            name="Mistral Vibe"
            descPre="API key for the Vibe CLI. Stored in "
            cmd="~/.vibe/.env"
            descPost=" and used when running Vibe as an agent tool."
            status="Configured"
            actionLabel="Update API key"
            primary
            footer="Get your key from "
            footerLink="Mistral Console."
          />
        </div>
      </div>
    </NCShell>
  );
}

function AuthCard({ name, descPre, cmd, descPost, status, actionLabel, link, primary, footer, footerLink }) {
  return (
    <div style={{ background: 'var(--bg-elev)', borderRadius: 10, padding: '16px 18px' }}>
      <div style={{ display: 'flex', alignItems: 'flex-start', gap: 14 }}>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontSize: 14, fontWeight: 600 }}>{name}</div>
          <div className="subtle" style={{ fontSize: 12.5, marginTop: 4, lineHeight: 1.55 }}>
            {descPre}
            <span className="mono" style={{
              background: 'var(--bg)', padding: '1px 6px', borderRadius: 4,
              color: 'var(--fg-muted)', fontSize: 11.5, border: '1px solid var(--line)',
            }}>{cmd}</span>
            {descPost}
          </div>
        </div>
        <span className="chip success dot" style={{ flexShrink: 0 }}>{status}</span>
      </div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 14, marginTop: 14 }}>
        <button className={primary ? 'btn primary' : 'btn'} style={primary ? { background: 'var(--accent)', color: '#fff' } : null}>
          {actionLabel}
        </button>
        {link && <a style={{ color: 'var(--accent)', fontSize: 13, textDecoration: 'none' }}>{link}</a>}
      </div>
      {footer && (
        <div className="subtle" style={{ fontSize: 12.5, marginTop: 12 }}>
          {footer}<a style={{ color: 'var(--accent)' }}>{footerLink}</a>
        </div>
      )}
    </div>
  );
}

function ScrSettingsGit({ theme, setTheme, collapsed, setCollapsed }) {
  return (
    <NCShell active="settings" collapsed={collapsed} setCollapsed={setCollapsed} theme={theme} setTheme={setTheme} sessions={SAMPLE_SESSIONS}>
      <div style={{ maxWidth: 1040 }}>
        <SettingsHeader />
        <SettingsTabs active="git" />
        <SectionLabel>Git Configuration</SectionLabel>
        <p className="subtle" style={{ fontSize: 12.5, marginTop: -4, marginBottom: 12 }}>
          Used as commit author when agents make changes on your behalf.
        </p>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
          <PrefRow title="user.name" desc="Author name written to git commits.">
            <input className="input" defaultValue="Jonah Einmahl" style={{ width: 240 }} />
          </PrefRow>
          <PrefRow title="user.email" desc="Author email written to git commits.">
            <input className="input mono" defaultValue="jonah@einmahl-works.de" style={{ width: 280 }} />
          </PrefRow>
          <PrefRow title="Sign commits" desc="Use the local GPG key to sign every commit.">
            <Toggle />
          </PrefRow>
          <PrefRow title="Default branch" desc="New repositories created from Nova Code use this branch name.">
            <input className="input mono" defaultValue="main" style={{ width: 180 }} />
          </PrefRow>
        </div>
      </div>
    </NCShell>
  );
}

// Themes tab — kept from the new design, large preview cards
function ScrSettingsThemes({ theme, setTheme, collapsed, setCollapsed }) {
  return (
    <NCShell active="settings" collapsed={collapsed} setCollapsed={setCollapsed} theme={theme} setTheme={setTheme} sessions={SAMPLE_SESSIONS}>
      <div style={{ maxWidth: 1040 }}>
        <SettingsHeader />
        <SettingsTabs active="themes" />
        <p className="muted" style={{ fontSize: 13, marginTop: -10, marginBottom: 20 }}>
          Active theme is highlighted. Themes adjust the accent color and surface tones across the app.
        </p>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 12 }}>
          {FULL_THEMES.map((t, i) => (
            <div key={i} style={{
              padding: 14, borderRadius: 10,
              background: 'var(--bg-elev)',
              boxShadow: t.active ? `inset 0 0 0 1.5px var(--accent)` : 'none',
              cursor: 'pointer',
            }}>
              <div style={{ height: 90, borderRadius: 6, background: t.bg, padding: 8, display: 'flex', gap: 6, marginBottom: 12, overflow: 'hidden' }}>
                <div style={{ width: 18, background: 'rgba(255,255,255,0.05)', borderRadius: 3 }} />
                <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 5 }}>
                  <div style={{ height: 8, width: '60%', background: 'rgba(255,255,255,0.18)', borderRadius: 2 }} />
                  <div style={{ height: 6, width: '90%', background: 'rgba(255,255,255,0.08)', borderRadius: 2 }} />
                  <div style={{ height: 6, width: '40%', background: t.accent, borderRadius: 2 }} />
                  <div style={{ height: 6, width: '70%', background: 'rgba(255,255,255,0.08)', borderRadius: 2 }} />
                </div>
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                <div style={{ width: 10, height: 10, borderRadius: 5, background: t.accent }} />
                <div style={{ fontSize: 13, fontWeight: 500 }}>{t.name}</div>
                {t.active && <span className="chip success" style={{ marginLeft: 'auto' }}>active</span>}
              </div>
            </div>
          ))}
        </div>
      </div>
    </NCShell>
  );
}

// Back-compat names
const ScrSettingsAppearance = ScrSettingsGeneral;
const ScrSettingsAgents = ScrSettingsGit;

Object.assign(window, { ScrSettingsGeneral, ScrSettingsGit, ScrSettingsThemes, ScrSettingsAppearance, ScrSettingsAgents });
