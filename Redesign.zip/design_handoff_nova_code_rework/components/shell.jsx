// Shared shell: sidebar, topbar, icons for Nova Code
// Export all components to window at end.

const NCIcon = ({ name, size = 16, stroke = 1.6, style }) => {
  const paths = {
    code:      'M8 6l-4 4 4 4 M16 6l4 4-4 4',
    home:      'M3 10.5L12 3l9 7.5V20a1 1 0 01-1 1h-5v-6H9v6H4a1 1 0 01-1-1z',
    folder:    'M3 7a2 2 0 012-2h3.5l2 2H19a2 2 0 012 2v8a2 2 0 01-2 2H5a2 2 0 01-2-2z',
    clock:     'M12 7v5l3 2 M12 21a9 9 0 100-18 9 9 0 000 18z',
    ruler:     'M4 14l10-10 6 6-10 10z M8 10l2 2 M11 7l2 2 M5 13l2 2',
    search:    'M11 18a7 7 0 100-14 7 7 0 000 14z M16.5 16.5L21 21',
    user:      'M12 12a4 4 0 100-8 4 4 0 000 8z M4 21c0-4 4-6 8-6s8 2 8 6',
    settings:  'M12 15a3 3 0 100-6 3 3 0 000 6z M19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 11-2.83 2.83l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 11-4 0v-.09A1.65 1.65 0 009 19.4a1.65 1.65 0 00-1.82.33l-.06.06a2 2 0 11-2.83-2.83l.06-.06A1.65 1.65 0 004.6 15a1.65 1.65 0 00-1.51-1H3a2 2 0 110-4h.09A1.65 1.65 0 004.6 9a1.65 1.65 0 00-.33-1.82l-.06-.06a2 2 0 112.83-2.83l.06.06A1.65 1.65 0 009 4.6 1.65 1.65 0 0010 3.09V3a2 2 0 014 0v.09c0 .67.4 1.27 1 1.51a1.65 1.65 0 001.82-.33l.06-.06a2 2 0 112.83 2.83l-.06.06c-.45.45-.58 1.15-.33 1.82 .24.6.84 1 1.51 1H21a2 2 0 110 4h-.09c-.67 0-1.27.4-1.51 1z',
    plus:      'M12 5v14 M5 12h14',
    edit:      'M11 4H5a2 2 0 00-2 2v13a2 2 0 002 2h13a2 2 0 002-2v-6 M18.5 2.5a2.12 2.12 0 013 3L12 15l-4 1 1-4z',
    archive:   'M3 7h18 M5 7v12a2 2 0 002 2h10a2 2 0 002-2V7 M10 11h4',
    trash:     'M3 6h18 M8 6V4a2 2 0 012-2h4a2 2 0 012 2v2 M19 6l-1 14a2 2 0 01-2 2H8a2 2 0 01-2-2L5 6',
    bolt:      'M13 2L3 14h7l-1 8 10-12h-7z',
    chart:     'M3 3v18h18 M7 15l3-3 3 3 5-5',
    grid:      'M3 3h7v7H3z M14 3h7v7h-7z M14 14h7v7h-7z M3 14h7v7H3z',
    list:      'M3 6h18 M3 12h18 M3 18h18',
    chev_left: 'M15 6l-6 6 6 6',
    chev_right:'M9 6l6 6-6 6',
    chev_down: 'M6 9l6 6 6-6',
    arrow_left:'M19 12H5 M12 5l-7 7 7 7',
    send:      'M22 2L11 13 M22 2l-7 20-4-9-9-4z',
    paperclip: 'M21 11l-8.5 8.5a5 5 0 01-7-7L14 4a3.5 3.5 0 015 5L10.5 17.5a2 2 0 01-3-3L15 7',
    git:       'M6 3v12 M6 15a3 3 0 100 6 3 3 0 000-6z M6 3a3 3 0 100 6 3 3 0 000-6z M18 9a3 3 0 100 6 3 3 0 000-6z M18 9c0 3-3 4-6 4-3 0-6 1-6 3',
    files:     'M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z M14 2v6h6 M9 13h6 M9 17h6',
    check:     'M4 12l5 5L20 6',
    x:         'M18 6L6 18 M6 6l12 12',
    terminal:  'M4 7l4 5-4 5 M12 19h8',
    sparkle:   'M12 3l2 5 5 2-5 2-2 5-2-5-5-2 5-2z',
    refresh:   'M3 12a9 9 0 0115-6.7L21 8 M21 3v5h-5 M21 12a9 9 0 01-15 6.7L3 16 M3 21v-5h5',
    expand:    'M4 14v6h6 M20 10V4h-6 M4 20l7-7 M20 4l-7 7',
    sun:       'M12 2v2 M12 20v2 M4.9 4.9l1.4 1.4 M17.7 17.7l1.4 1.4 M2 12h2 M20 12h2 M4.9 19.1l1.4-1.4 M17.7 6.3l1.4-1.4 M12 7a5 5 0 100 10 5 5 0 000-10z',
    moon:      'M21 12.8A9 9 0 1111.2 3a7 7 0 009.8 9.8z',
    panel:     'M3 4h18v16H3z M9 4v16',
    sidebar:   'M3 5a2 2 0 012-2h14a2 2 0 012 2v14a2 2 0 01-2 2H5a2 2 0 01-2-2z M9 3v18',
    command:   'M18 3a3 3 0 00-3 3v12a3 3 0 003 3 M6 3a3 3 0 013 3v12a3 3 0 01-3 3 M9 9h6v6H9z',
  };
  const d = paths[name];
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor"
      strokeWidth={stroke} strokeLinecap="round" strokeLinejoin="round" style={style}>
      <path d={d} />
    </svg>
  );
};

// Nova Code logomark — simple rotated caret bracket, monogram-ish
const NCLogo = ({ size = 22 }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
    <rect x="1.5" y="1.5" width="21" height="21" rx="5"
      stroke="var(--accent)" strokeWidth="1.4" fill="var(--accent-soft)"/>
    <path d="M9 8l-3 4 3 4 M15 8l3 4-3 4" stroke="var(--accent)" strokeWidth="1.6"
      strokeLinecap="round" strokeLinejoin="round"/>
  </svg>
);

// Sidebar — collapsible to icon rail
function NCSidebar({ active = 'home', collapsed = false, sessions = [] }) {
  const navItems = [
    { id: 'home',       label: 'Home',           icon: 'home' },
    { id: 'workspaces', label: 'Workspaces',     icon: 'folder' },
    { id: 'automations',label: 'Automations',    icon: 'clock' },
    { id: 'rules',      label: 'Rule templates', icon: 'ruler' },
  ];
  const W = collapsed ? 56 : 232;
  return (
    <aside style={{
      width: W, flexShrink: 0, height: '100%',
      background: 'var(--bg)',
      borderRight: '1px solid var(--line)',
      display: 'flex', flexDirection: 'column',
      transition: 'width .18s',
    }}>
      {/* brand */}
      <div style={{
        height: 56, display: 'flex', alignItems: 'center',
        padding: collapsed ? '0' : '0 18px',
        justifyContent: collapsed ? 'center' : 'flex-start',
        gap: 10,
      }}>
        <NCLogo size={22} />
        {!collapsed && (
          <div style={{ fontWeight: 600, fontSize: 14.5, letterSpacing: '-0.01em' }}>
            Nova Code
          </div>
        )}
      </div>

      {/* primary nav */}
      <nav style={{ padding: collapsed ? '4px 8px' : '4px 10px', display: 'flex', flexDirection: 'column', gap: 1 }}>
        {navItems.map((it) => {
          const isActive = it.id === active;
          return (
            <div key={it.id} title={collapsed ? it.label : null}
              style={{
                display: 'flex', alignItems: 'center',
                gap: 10,
                height: 32, padding: collapsed ? 0 : '0 10px',
                justifyContent: collapsed ? 'center' : 'flex-start',
                borderRadius: 6,
                color: isActive ? 'var(--fg)' : 'var(--fg-muted)',
                background: isActive ? 'var(--bg-elev)' : 'transparent',
                cursor: 'pointer',
                position: 'relative',
                fontSize: 13.5,
                fontWeight: isActive ? 500 : 400,
              }}>
              {isActive && !collapsed && <div style={{
                position: 'absolute', left: -10, top: 8, bottom: 8, width: 2,
                background: 'var(--accent)', borderRadius: 2,
              }}/>}
              <NCIcon name={it.icon} size={15} />
              {!collapsed && <span>{it.label}</span>}
            </div>
          );
        })}
      </nav>

      {!collapsed && (
        <div style={{ padding: '18px 18px 6px', marginTop: 14 }}>
          <div className="eyebrow">// sessions</div>
        </div>
      )}

      {/* sessions list */}
      <div style={{ flex: 1, overflowY: 'auto', padding: collapsed ? '8px 8px' : '4px 10px', display: 'flex', flexDirection: 'column', gap: 1 }}>
        {sessions.map((s, i) => (
          <div key={i} title={collapsed ? s.name : null}
            style={{
              display: 'flex', alignItems: 'center', gap: 10,
              height: collapsed ? 32 : 38, padding: collapsed ? 0 : '0 10px',
              justifyContent: collapsed ? 'center' : 'flex-start',
              borderRadius: 6, cursor: 'pointer',
              color: 'var(--fg-muted)',
            }}
            className="row-hover"
          >
            <span className={`status-dot ${s.status || 'idle'}`}></span>
            {!collapsed && (
              <div style={{ minWidth: 0, flex: 1 }}>
                <div style={{ fontSize: 13, color: 'var(--fg)', fontWeight: 400, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{s.name}</div>
                <div className="mono" style={{ fontSize: 10.5, color: 'var(--fg-subtle)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{s.path}</div>
              </div>
            )}
          </div>
        ))}
      </div>

      {/* settings pinned */}
      <div style={{ padding: collapsed ? '10px 8px' : '10px 10px', borderTop: '1px solid var(--line)' }}>
        <div title={collapsed ? 'Settings' : null}
          style={{
            display: 'flex', alignItems: 'center', gap: 10,
            height: 32, padding: collapsed ? 0 : '0 10px',
            justifyContent: collapsed ? 'center' : 'flex-start',
            borderRadius: 6, cursor: 'pointer',
            color: 'var(--fg-muted)', fontSize: 13.5,
          }}
          className="row-hover">
          <NCIcon name="settings" size={15} />
          {!collapsed && <span>Settings</span>}
        </div>
      </div>
    </aside>
  );
}

function NCTopbar({ collapsed, onToggleSidebar, theme, onToggleTheme, user = 'Jonah' }) {
  return (
    <header style={{
      height: 52,
      display: 'flex', alignItems: 'center',
      padding: '0 16px',
      borderBottom: '1px solid var(--line)',
      background: 'var(--bg)',
      gap: 12,
      flexShrink: 0,
    }}>
      <button className="btn ghost icon sm" onClick={onToggleSidebar} title="Toggle sidebar">
        <NCIcon name="sidebar" size={15} />
      </button>

      {/* search */}
      <div style={{
        flex: 1, maxWidth: 520,
        display: 'flex', alignItems: 'center', gap: 8,
        height: 30, padding: '0 10px',
        background: 'var(--bg-elev)',
        borderRadius: 6,
        border: '1px solid transparent',
        color: 'var(--fg-subtle)',
        cursor: 'text',
        fontSize: 13,
      }}>
        <NCIcon name="search" size={14} />
        <span style={{ color: 'var(--fg-subtle)' }}>Search sessions, files, workspaces…</span>
        <span style={{ flex: 1 }} />
        <kbd className="k">⌘K</kbd>
      </div>

      <div style={{ flex: 1 }} />

      {/* theme toggle */}
      <button className="btn ghost icon sm" onClick={onToggleTheme} title="Toggle theme">
        <NCIcon name={theme === 'dark' ? 'sun' : 'moon'} size={14} />
      </button>

      {/* user */}
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, paddingLeft: 8, borderLeft: '1px solid var(--line)', marginLeft: 4 }}>
        <div style={{
          width: 24, height: 24, borderRadius: 12,
          background: 'var(--accent-soft)',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontSize: 11.5, fontWeight: 600,
          color: 'var(--accent)',
        }}>{user.charAt(0)}</div>
        <span style={{ fontSize: 13, color: 'var(--fg-muted)' }}>{user}</span>
      </div>
    </header>
  );
}

// Page shell wrapper used inside every artboard
function NCShell({ active, collapsed, setCollapsed, theme, setTheme, sessions, children }) {
  return (
    <div className="nc" data-theme={theme} style={{ width: '100%', height: '100%', display: 'flex', background: 'var(--bg)' }}>
      <NCSidebar active={active} collapsed={collapsed} sessions={sessions} />
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', minWidth: 0 }}>
        <NCTopbar
          collapsed={collapsed}
          onToggleSidebar={() => setCollapsed(!collapsed)}
          theme={theme}
          onToggleTheme={() => setTheme(theme === 'dark' ? 'light' : 'dark')}
        />
        <main style={{ flex: 1, overflowY: 'auto', padding: '32px 40px 40px' }}>
          {children}
        </main>
      </div>
    </div>
  );
}

// Common sample session list
const SAMPLE_SESSIONS = [
  { name: 'Session 21/04/2026', path: 'project-management', status: 'busy' },
  { name: 'CI',                 path: 'project-management', status: 'idle' },
  { name: 'Person',             path: 'project-management', status: 'idle' },
  { name: 'Fixes',              path: 'project-management', status: 'idle' },
  { name: 'Invitation',         path: 'project-management', status: 'idle' },
];

Object.assign(window, { NCIcon, NCLogo, NCSidebar, NCTopbar, NCShell, SAMPLE_SESSIONS });
